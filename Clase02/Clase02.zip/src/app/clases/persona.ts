export class Persona {
    nombre: string;
    mail: string;

public constructor(nombre: string, mail: string) {
    this.nombre = nombre;
    this.mail = mail;
}
}
