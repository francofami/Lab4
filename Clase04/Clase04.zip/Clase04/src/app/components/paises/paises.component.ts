import { Component, OnInit } from '@angular/core';
import { PaisesService } from 'src/app/servicios/paises.service';

@Component({
  selector: 'app-paises',
  templateUrl: './paises.component.html',
  styleUrls: ['./paises.component.css']
})
export class PaisesComponent implements OnInit {

  lista;

  constructor(private user: PaisesService) { }

  ngOnInit() {
    this.user.getPaises().subscribe(data => {
      this.lista = data;
      console.log(this.lista);
    });
  }

}
