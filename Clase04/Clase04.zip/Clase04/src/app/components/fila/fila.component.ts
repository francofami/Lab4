import { Component, OnInit, Input } from '@angular/core';
import { Persona } from 'src/app/clases/persona';

@Component({
  selector: '[app-fila]', // Pongo entre [] para
  templateUrl: './fila.component.html',
  styleUrls: ['./fila.component.css']
})
export class FilaComponent implements OnInit {

  @Input() item: Persona;

  constructor() { }

  ngOnInit() {
  }

}
