import { PaisesService } from './servicios/paises.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { SaludarComponent } from './components/saludar/saludar.component';
import { DatosComponent } from './components/datos/datos.component';
import { FormComponent } from './components/form/form.component';
import { FilaComponent } from './components/fila/fila.component';
import { LicenciaPipe } from './pipes/licencia.pipe';
import { PaisesComponent } from './components/paises/paises.component';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    SaludarComponent,
    DatosComponent,
    FormComponent,
    FilaComponent,
    LicenciaPipe,
    PaisesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [PaisesService, HttpClientModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
