import { LicenciaPipe } from './licencia.pipe';

describe('LicenciaPipe', () => {
  it('create an instance', () => {
    const pipe = new LicenciaPipe();
    expect(pipe).toBeTruthy();
  });
});
