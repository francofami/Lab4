import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'licencia'
})
export class LicenciaPipe implements PipeTransform {

  transform(value: string, args?: any): any {
    value = '<span style="color: red">' + value + '</span>';
    return value;
  }

}
