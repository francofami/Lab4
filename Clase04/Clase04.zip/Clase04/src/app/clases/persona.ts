export class Persona {
    nombre: string;
    sexo: string;
    sueldo: number;
    edad: number;
    licencia: string;
    fecha: Date;

public constructor(nombre: string, sexo: string, sueldo: number, edad: number, licencia: string) {
    this.nombre = nombre;
    this.sexo = sexo;
    this.sueldo = sueldo;
    this.edad = edad;
    this.licencia = licencia;
    this.fecha = new Date();
}
}
