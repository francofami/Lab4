import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Persona } from 'src/app/clases/persona';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  nombre: string;
  mail: string;
  sexo: string;
  sueldo: number;
  edad: number;
  licencia: string;
  persona: Persona;
  fecha: Date;
  enviado = true;

  @Output() cargar = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  manejadora() {
    // this.enviado = !this.enviado;
    this.persona = new Persona(this.nombre, this.sexo, this.sueldo, this.edad, this.licencia);
    console.log(this.persona);
    this.cargar.emit(this.persona);
  }

}
