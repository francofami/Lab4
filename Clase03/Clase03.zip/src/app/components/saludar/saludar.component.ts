import { Component, OnInit } from '@angular/core';
import { Persona } from 'src/app/clases/persona';

@Component({
  selector: 'app-saludar',
  templateUrl: './saludar.component.html',
  styleUrls: ['./saludar.component.css']
})
export class SaludarComponent implements OnInit {

  nombre = 'Franco';
  linkImg = 'https://upload.wikimedia.org/wikipedia/commons/d/db/Escudo_del_Club_Atl%C3%A9tico_Independiente.svg';
  width = 200;
  height = 200;

  personas: any = [];

  constructor() { }

  ngOnInit() {
  }

  cargar(datos: Persona) {
    this.personas.push(datos);
    console.log(this.personas);
  }

}
