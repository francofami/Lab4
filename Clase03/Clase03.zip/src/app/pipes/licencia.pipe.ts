import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'licencia'
})
export class LicenciaPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    string="";
    //var string = value.replace('<td _ngcontent-qyi-c4=""></td>', '<span style="color: red"></span>')
    return string;
  }

}
