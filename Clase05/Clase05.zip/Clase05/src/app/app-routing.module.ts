import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Importante!! Importar los componentes acá:
import { HomeComponent } from './pages/home/home.component';
import { ErrorComponent } from './pages/error/error.component';
import { ClientesComponent } from './pages/clientes/clientes.component';
import { DetalleComponent } from './pages/detalle/detalle.component';

const routes: Routes = [
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {path: 'clientes', component: ClientesComponent,
  children: [
    {path: 'detalle/:id', component: DetalleComponent} // El : hace que entienda que recibe una variable
  ]},
  {path: '**', component: ErrorComponent}, // Hace que si no pongo /algo me muestre una pantalla de error (poner esto a lo último)
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
