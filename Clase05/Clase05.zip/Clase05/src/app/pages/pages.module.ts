import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ErrorComponent } from './error/error.component';
import { ClientesComponent } from './clientes/clientes.component';
import { DetalleComponent } from './detalle/detalle.component';

import {MatButtonModule} from '@angular/material/button';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';

// import { AngularFireModule } from '@angular/fire';
// import { AngularFirestore } from '@angular/fire/firestore';




@NgModule({
  declarations: [ HomeComponent, ErrorComponent, ClientesComponent, DetalleComponent ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    MatButtonModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatIconModule,
    // AngularFireModule,
    // AngularFirestore,
  ]
})
export class PagesModule { }
